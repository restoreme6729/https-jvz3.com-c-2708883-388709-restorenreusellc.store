# GetResponse Magento 2 Integration
GetResponse Magento 2 plugin.
 
To install plugin run in console commands:

3. `composer require "getresponse/magento2:20.3.*"`
3. `php bin/magento module:enable GetResponse_GetResponseIntegration`
4. `php bin/magento setup:upgrade`