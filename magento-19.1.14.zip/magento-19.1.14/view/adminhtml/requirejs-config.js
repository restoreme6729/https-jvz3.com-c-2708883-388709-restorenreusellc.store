var config = {
    map: {
        '*': {
            createList: "GetResponse_GetResponseIntegration/js/createList",
            customsGrid: "GetResponse_GetResponseIntegration/js/customsGrid",
            ecommerce: "GetResponse_GetResponseIntegration/js/ecommerce",
            exportContacts: "GetResponse_GetResponseIntegration/js/exportContacts",
            registration: "GetResponse_GetResponseIntegration/js/registration",
            settings: "GetResponse_GetResponseIntegration/js/settings",
            webform: "GetResponse_GetResponseIntegration/js/webform",
        }
    }
};
