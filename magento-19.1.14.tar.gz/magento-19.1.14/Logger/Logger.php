<?php
namespace GetResponse\GetResponseIntegration\Logger;

use Monolog\Logger as MonologLogger;

/**
 * Class Logger
 * @package GetResponse\GetResponseIntegration\Logger
 */
class Logger extends MonologLogger
{
}