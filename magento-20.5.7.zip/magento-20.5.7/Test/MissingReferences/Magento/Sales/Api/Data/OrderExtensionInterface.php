<?php declare(strict_types=1);
namespace Magento\Sales\Api\Data;

interface OrderExtensionInterface
{
}
