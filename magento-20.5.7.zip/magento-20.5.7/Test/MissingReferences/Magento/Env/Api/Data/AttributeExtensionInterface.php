<?php declare(strict_types=1);
namespace Magento\Eav\Api\Data;

interface AttributeExtensionInterface
{
}
