<?php declare(strict_types=1);
namespace Magento\Quote\Api\Data;

interface CartExtensionInterface
{
}
