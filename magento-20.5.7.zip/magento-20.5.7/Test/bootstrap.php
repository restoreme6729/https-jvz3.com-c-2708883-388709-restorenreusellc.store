<?php declare(strict_types=1);
