<?php

declare(strict_types=1);

namespace GetResponse\GetResponseIntegration\Domain\SharedKernel\Exception;

use Exception;

class ListValidationException extends Exception
{
}
