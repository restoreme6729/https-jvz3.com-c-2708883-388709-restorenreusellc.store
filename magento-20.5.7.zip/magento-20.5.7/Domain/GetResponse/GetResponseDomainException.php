<?php

declare(strict_types=1);

namespace GetResponse\GetResponseIntegration\Domain\GetResponse;

use Exception;

class GetResponseDomainException extends Exception
{
}
