# Changelog

## [20.5.7] - 2022-07-10
### Fix
- added doctype for php8.1 compatibility

## [20.5.6] - 2022-07-06
### Fix
- fixed error of missing object in observer

## [20.5.5] - 2022-03-14
### Fix
- fixed error when editing customer in admin panel

## [20.5.4] - 2022-03-02
### Fix
- added fix for short description and description
- changed orderNo field to order_number

## [20.5.3] - 2021-12-13
### Fix
- added fix customer serialization

## [20.5.2] - 2021-10-26
### Fix
- added fix for product short description and description

## [20.5.1] - 2021-10-04
### Changed
- gitlab-ci
