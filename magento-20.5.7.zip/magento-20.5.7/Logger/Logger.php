<?php

declare(strict_types=1);

namespace GetResponse\GetResponseIntegration\Logger;

use Monolog\Logger as MonologLogger;

class Logger extends MonologLogger
{
}
