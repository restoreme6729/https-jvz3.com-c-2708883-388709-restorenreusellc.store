<?php

declare(strict_types=1);

namespace GetResponse\GetResponseIntegration\Block\Admin;

class Transition extends AdminTemplate
{
}
