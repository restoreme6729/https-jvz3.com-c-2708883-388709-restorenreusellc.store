require(['jquery'], function($) {
  console.log('test dropdown 2');
});