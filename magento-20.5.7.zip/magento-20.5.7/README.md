# GetResponse Magento 2 Integration
GetResponse Magento 2 plugin.
 
To install plugin run in console commands:

1. `composer require "getresponse/magento2"`
2. `php bin/magento module:enable GetResponse_GetResponseIntegration`
3. `php bin/magento setup:upgrade`
4. ...
